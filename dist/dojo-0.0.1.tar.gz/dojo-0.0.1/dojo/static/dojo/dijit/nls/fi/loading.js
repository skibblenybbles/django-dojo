define(
({
	loadingState: "Lataus on meneillään...",
	errorState: "On ilmennyt virhe."
})
);
