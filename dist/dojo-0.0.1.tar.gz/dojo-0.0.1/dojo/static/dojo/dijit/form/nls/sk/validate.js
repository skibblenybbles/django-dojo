define(
({
	invalidMessage: "Zadaná hodnota nie je platná.",
	missingMessage: "Táto hodnota je povinná.",
	rangeMessage: "Táto hodnota je mimo rozsah."
})
);
