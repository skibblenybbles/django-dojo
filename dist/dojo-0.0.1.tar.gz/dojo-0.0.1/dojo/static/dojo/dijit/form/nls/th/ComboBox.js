define(
({
		previousMessage: "การเลือกก่อนหน้า",
		nextMessage: "การเลือกเพิ่มเติม"
})
);
