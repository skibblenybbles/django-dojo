dojo.provide("dijit.tests._BidiSupport.tree.module");

try{

	doh.registerUrl("dijit.tests._BidiSupport.tree.ProgrammaticTree.html", dojo.moduleUrl("dijit","tests/_BidiSupport/tree/ProgrammaticTree.html"), 999999);

}catch(e){

	doh.debug(e);

}
