dojo.provide("dijit.tests._BidiSupport.module");

try{

	dojo.require("dijit.tests._BidiSupport.form.module");

	dojo.require("dijit.tests._BidiSupport.BidiSupportModule.module");

	dojo.require("dijit.tests._BidiSupport.inheritance.module");

	dojo.require("dijit.tests._BidiSupport.dynamicallyChangeTextDir.module");

	dojo.require("dijit.tests._BidiSupport.tree.module");
	
	dojo.require("dijit.tests._BidiSupport.widgets.module");

}catch(e){

	doh.debug(e);

}
