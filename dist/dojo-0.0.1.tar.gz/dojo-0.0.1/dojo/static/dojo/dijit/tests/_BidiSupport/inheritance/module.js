dojo.provide("dijit.tests._BidiSupport.inheritance.module");

try{

	doh.registerUrl("dijit.tests._BidiSupport.inheritance.Inher-Simple", dojo.moduleUrl("dijit", "tests/_BidiSupport/inheritance/Inher-Simple.html"));
 
	doh.registerUrl("dijit.tests._BidiSupport.inheritance.Inher-MarkupContainers", dojo.moduleUrl("dijit", "tests/_BidiSupport/inheritance/Inher-MarkupContainers.html"));	

	doh.registerUrl("dijit.tests._BidiSupport.inheritance.Inher-ComplexMarkupContainers", dojo.moduleUrl("dijit", "tests/_BidiSupport/inheritance/Inher-ComplexMarkupContainers.html"));

}catch(e){

	doh.debug(e);

}
