dojo.provide("dijit.tests._BidiSupport.widgets.module");

try{

	doh.registerUrl("dijit.tests._BidiSupport.widgets.Tooltip.html", dojo.moduleUrl("dijit","tests/_BidiSupport/widgets/Tooltip.html"));
	doh.registerUrl("dijit.tests._BidiSupport.widgets.MenuItem.html", dojo.moduleUrl("dijit","tests/_BidiSupport/widgets/MenuItem.html"));

}catch(e){

	doh.debug(e);

}
