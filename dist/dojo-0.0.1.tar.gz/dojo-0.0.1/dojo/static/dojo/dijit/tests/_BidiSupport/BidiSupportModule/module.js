dojo.provide("dijit.tests._BidiSupport.BidiSupportModule.module");

try{

	dojo.require("dijit.tests._BidiSupport.BidiSupportModule.BidiSupportTest");

}catch(e){

	doh.debug(e);

}
