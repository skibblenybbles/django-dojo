dojo.provide("dijit.tests._BidiSupport.dynamicallyChangeTextDir.module");

try{

	doh.registerUrl("dijit.tests._BidiSupport.dynamicallyChangeTextDir.DynamicChangeTextDir", dojo.moduleUrl("dijit","tests/_BidiSupport/dynamicallyChangeTextDir/DynamicChangeTextDir.html"));
	
}catch(e){

	doh.debug(e);

}
